import unittest
from shortest_path import *

class testcases(unittest.TestCase):
    def test_algorithm(self):
        g = Graph()
        g.addVertex('a')
        g.addVertex('b')
        g.addVertex('c')
        g.addVertex('d')
        g.addVertex('e')
        g.addVertex('f')
        g.add_edge('a', 'b', 7)
        g.add_edge('a', 'c', 9)
        g.add_edge('a', 'f', 14)
        g.add_edge('b', 'c', 10)
        g.add_edge('b', 'd', 15)
        g.add_edge('c', 'd', 11)
        g.add_edge('c', 'f', 2)
        g.add_edge('d', 'e', 6)
        g.add_edge('e', 'f', 9)
        self.assertEqual(g.add)
