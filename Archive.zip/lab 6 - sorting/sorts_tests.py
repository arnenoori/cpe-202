import unittest
from sorts import *


class Test(unittest.TestCase):




if __name__ == "__main__":
    unittest.main()
